#include <stdio.h>

// Define the customer struct
struct customer {
    int id;
    long long phoneNumber;
    char name[50];
};

// Function to display customer information
void displayCustomer(struct customer customers[], int size) {
    printf("\nCustomer Information:\n");
    printf("ID\tPhone Number\tName\n");

	int i;
    for (i = 0; i < size; i++) {
        if (customers[i].id != -1) {
            printf("%d\t%lld\t\t%s\n", customers[i].id, customers[i].phoneNumber, customers[i].name);
        }
    }
}

int main() {
    // Define an array of customer structs with three data entries
    struct customer customers[3] = {
        {1, 1234567890, "John Doe"},
        {2, 9876543210, "Jane Smith"},
        {3, 5555555555, "Bob Johnson"}
    };

    // Display initial customer information
    displayCustomer(customers, 3);

    // Ask the user to enter an id to remove
    int idToRemove;
    printf("\nEnter the ID to remove: ");
    scanf("%d", &idToRemove);

    // Search for the customer with the specified id and remove the data
    int found = 0;
    int i;
    for (i = 0; i < 3; i++) {
        if (customers[i].id == idToRemove) {
            found = 1;
            // Remove data by setting the id to -1 (assuming id cannot be negative)
            customers[i].id = -1;
            customers[i].phoneNumber = 0;
            customers[i].name[0] = '\0';
            break;
        }
    }

    // Display updated customer information
    if (found) {
        printf("\nData with ID %d removed.\n", idToRemove);
        displayCustomer(customers, 3);
    } else {
        printf("\nCustomer with ID %d not found.\n", idToRemove);
    }

    return 0;
}

