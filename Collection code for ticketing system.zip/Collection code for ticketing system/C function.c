char LOS(int acd){
	char los;
	
	if(acd <= 10){
		los='A';
	}
	else if(acd>=10 && acd <=15){
		los='B';
	}
}
