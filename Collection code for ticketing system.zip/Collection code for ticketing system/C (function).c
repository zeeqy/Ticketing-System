#include<stdio.h>
//declare
int calculateNumbers(int,int);

int main()
{
	int answer,num1,num2,i;
	
	for(i=0;i<5;i++)
	{
		
		printf("\nEnter 2 integers numbers: ");
		scanf("%d %d",&num1,&num2);
		
		//call
		answer = calculateNumbers(num1,num2);
		printf("\nThe addition is equal: %d",answer);
		
	}
	
	return 0;
}//main() end

//definition

int calculateNumbers(int n1, int n2)
{
	int opr,result=0;
	
printf("\nChoose to perform addition[1] or substraction[2]:");
scanf("%d",&opr);

if(opr==1)
result = n1+n2;

else
result = n1-n2;

return result;
}

