#include <stdio.h>
#include <string.h>

// Defining the Ticket struct
struct Ticket {
	
	char custID[5];
    char custName[50];
    char custPhoneNum[15];
    int custAge;
    char custAdd[100];
    char ticketID[100];
    char seatSection[50];
    char eventDate;
    
};

// Function prototypes
float calcPrice( struct Ticket[] , int  );
void calcTotalSales( struct Ticket[] , int  );
void calcHighest( struct Ticket[] , int , int );
void calcLowest( struct Ticket[] , int , int );
double calcTotalSale(struct Ticket[], int , int );
int calcTotalAttendees(struct Ticket[], int , int );
void ticketInfo(struct Ticket[], int, int );


float calcPrice( struct Ticket t[] , int i )
{
	float total = 0;
	
        if( t[i].ticketID == "Aina Abdul Concert" ) 
        {
            if( t[i].seatSection == "CAT 1 (VIP Pass)")
                total = 300.00;
            else
			if( t[i].seatSection == "CAT 2")
                total = 250.00;
            else 
			if( t[i].seatSection == "CAT 3")
                total = 100.00;
        }
        else
		if( t[i].ticketID == "Siti Nurhaliza Concert"  ) 
        {
            if( t[i].seatSection == "CAT 1 (VIP Pass)")
                total = 500.00;
            else 
			if( t[i].seatSection == "CAT 2")
                total = 350.00;
            else 
			if( t[i].seatSection == "CAT 3")
                total = 200.00;
        }
        else 
		if( t[i].event == "Noraniza Idris Concert" ) 
        {
            if( t[i].seatSection == "CAT 1 (VIP Pass)")
                total = 150.00;
            else 
			if( t[i].seatSection == "CAT 2")
                total = 100.00;
            else 
			if( t[i].seatSection == "CAT 3")
                total = 50.00;
        }
        
	return total;
}

//Calculate the sum of all earnings from each event based on their name
void calcTotalSales( struct Ticket t[] , int size )
{
	int i;
	float sumAA = 0.00;
	float sumSN = 0.00;
	float sumNI = 0.00;
	
	for ( i = 0; i < size ; i++ )
	{
	if( t[i].ticketID == "Aina Abdul Concert" ) 
            sumAA = sumAA + calcPrice( t , i );
    else 
	if( t[i].ticketID == "Siti Nurhaliza Concert"  ) 
        sumSN = sumSN + calcPrice( t , i  );
    else 
	if( t[i].ticketID == "Noraniza Idris Concert" ) 
        sumNI = sumNI + calcPrice( t , i  );
	}
    
    printf("\nTotal Earnings for Each Concert: ");
    printf("\nAina Abdul's Concert : RM%.2f", sumAA);
    printf("\nSiti Nurhaliza's Concert : RM%.2f", sumSN);
    printf("\nNoraniza Idris's Concert : RM%.2f", sumNI);
}

//Determine the maximum sales and attendees gained by comparing each event thoroughly
void calcHighest( struct Ticket t[] , int i , int size )
{
	int countAA = 0;
	int countSN = 0;
	int countNI = 0;
	int highestAtt = 0;
	float highestSales = 0.00; 
	float sumAA = 0.00;
	float sumSN = 0.00;
	float sumNI = 0.00;	
	char SalesName[50];
	char AttName[50];
	
	for ( i = 0; i < size; i++ ) 
	{
		if( t[i].event == 1 ) 
            {
				sumAA = sumAA + calcPrice( t , i );
				countAA = countAA + 1;
			}
        else 
		if( t[i].event == 2 ) 
            {
				sumSN = sumSN + calcPrice( t , i );
				countSN = countSN + 1;
			}
        else 
		if( t[i].event == 3 ) 
            {
				sumNI = sumNI + calcPrice( t , i );
				countNI = countNI + 1;
			}
    }
    
    if ( sumAA > highestSales )
        {
		  highestSales = sumAA;
		  strcpy( SalesName , "Aina Abdul's Concert");
    	}
    if ( sumSN > highestSales )
        {
		  highestSales = sumSN;
		  strcpy( SalesName,"Siti Nurhaliza's' Concert");
    	}
    if ( sumNI > highestSales )
        {
		  highestSales = sumNI;
		  strcpy( SalesName , "Noraniza Idris's' Concert");
    	}
         
    if ( countAA > highestAtt )
        {
         highestAtt = countAA;
         strcpy( AttName , "Aina Abdul's Concert" );
    	}
    if ( countSN > highestAtt )
        {
		  highestAtt = countSN;
		  strcpy( AttName , "Siti Nurhaliza's Concert" );
    	}
    if ( countNI > highestAtt )
        {
		  highestAtt = countNI;
		  strcpy( AttName , "Noraniza Idris's Concert" );
    	}
    
	printf("\nName of highest attended event : %s", AttName );     
    printf("\nTotal attendees for the highest event : %d", highestAtt);
    
    printf("\nName of highest sales gained from an event : %s", SalesName);     
    printf("\nTotal sales for the highest event : %.2f", highestSales);
    
}

//Determine the lowest sales and attendees gained by comparing each event thoroughly
void calcLowest( struct Ticket t[] , int i , int size )
{
	int countAA = 0;
	int countSN = 0;
	int countNI = 0;
	int lowestAtt = 999;
	float lowestSales = 999999.00; 
	float sumAA = 0.00;
	float sumSN = 0.00;
	float sumNI = 0.00;
	char SalesName[50];
	char AttName[50];
	
	for (i = 0; i < size; i++ ) 
	{
		if( t[i].event == 1 ) 
            {
				sumAA = sumAA + calcPrice( t , i );
				countAA = countAA + 1;
			}
        else 
		if( t[i].event == 2 ) 
            {
				sumSN = sumSN + calcPrice( t , i );
				countSN = countSN + 1;
			}
        else 
		if( t[i].event == 3 ) 
			{
				sumNI = sumNI + calcPrice( t , i );
				countNI = countNI + 1;
			}
    }
    
    if ( sumAA < lowestSales )
        {
		  lowestSales = sumAA;
		  strcpy( SalesName , "Aina Abdul's Concert");
    	}
    if ( sumSN < lowestSales )
        {
		  lowestSales = sumSN;
		  strcpy( SalesName , "Siti Nurhaliza's Concert");
    	}
    if ( sumNI < lowestSales )
        {
		  lowestSales = sumNI;
		  strcpy( SalesName , "Noraniza Idris's Concert");
    	}
         
    if ( countAA < lowestAtt )
        {
         lowestAtt = countAA;
         strcpy( AttName , "Aina Abdul's Concert" );
    	}
    if ( countSN < lowestAtt )
        {
		  lowestAtt = countSN;
		  strcpy( AttName , "Siti Nurhaliza's Concert" );
    	}
    if ( countNI < lowestAtt )
        {
		  lowestAtt = countNI;
		  strcpy( AttName , "Noraniza Idris's Concert");
    	}
    
	printf("\nName of lowest attended event : %s", AttName);     
    printf("\nTotal attendees for the lowest event : %d", lowestAtt);
    
    printf("\nName of lowest sales gained from an event : %s", SalesName);     
    printf("\nTotal sales for the lowest event : %.2f", lowestSales);
    
}

int calcTotalAttendees(struct Ticket t[] , int numOfCustomers, int eventNum){
	int totalAttendees=0;
	int i;
	for( i=0; i<numOfCustomers; i++){
		if( t[i].event == eventNum){
			totalAttendees = totalAttendees + 1;
		}
	}
	
	return totalAttendees;
}

void updateData(struct Ticket t[], int i, int size){
	printf("\n");
    char enterID[100];
    char enterName[100];
    int index = 0;
    printf("Enter customer's ID to update phone Numbers:\n");
    scanf("%s", enterID);
    

    int found = 0;
    for (i = 0; i < size; i++) {
        if ( strcmp(t[i].custID, enterID) == 0 ) 
		{
			index = i;
            char newPhone[50];
            printf("Enter new phone number to update: ");
            scanf("%s", newPhone);
            strcpy(t[i].custPhoneNum, newPhone);
            found = 1;
            break;
        }
    }

    if (found) 
	{
        printf("\nPhone number updated successfully.\n");
        printf("Updated details: \n");
        printf("Name: %s\n", t[index].custName);
        printf("Age: %d\n", t[index].custAge);
        printf("Address: %s\n", t[index].custAdd);
        printf("Phone Number: %s\n", t[index].custPhoneNum);
        printf("\n");
    } else {
        printf("Customer not found.\n");
    }
	
}

void removeData(struct Ticket t[], int i, int size){
    char findID[100];
    printf("Enter ID to remove your orders: ");
    scanf("%s", findID);
    
    int found = 0;
    for(i = 0; i < size; i++){
        if(strcmp(t[i].custID, findID) == 0){
            found = 1;
            int s;
            for(s = i; s < size-1; s++){
                strcpy(t[s].custID, t[s+1].custID);
                strcpy(t[s].custName, t[s+1].custName);
                t[s].custAge = t[s+1].custAge;
                strcpy(t[s].custAdd, t[s+1].custAdd);
                strcpy(t[s].custPhoneNum, t[s+1].custPhoneNum);
                strcpy( t[s].eventName , t[s+1].eventName);
                strcpy(t[s].date, t[s+1].date);
                t[s].seatSection = t[s+1].seatSection;
                t[s].ticketPrice = t[s+1].ticketPrice;
            }
        }
    }
    
    if(!found){
		 printf("ID are not in the data. Please enter a valid ID. \n");
	}
}


int main(){
	int size = 3;
	struct Ticket t[ size ];
	
	printf("Welcome to Ticket Concert Management System!");             
    printf("\n\t----------------------------------------");
    printf("\n\t\t\tTicket List");                                         
    printf("\n\t----------------------------------------");
        
    printf("\n\tConcert 1:");                                          
    printf("\n\tTicket ID: AA001");
    printf("\n\tEvent Name: Aina Abdul Concert");
    printf("\n\tEvent Date Available:");
    printf("\n\t\t[1] 24/01/2024 (Wednesday) - 8pm");
    printf("\n\t\t[2] 28/02/2024 (Wednesday) - 8pm");
    printf("\n\tSeat Section:");
    printf("\n\t\t[1] CAT 1 (VIP Pass) - RM 300.00");
    printf("\n\t\t[2] CAT 2 - RM 250.00");
    printf("\n\t\t[3] CAT 3 - RM 100.00");
        
    printf("\n\n\tConcert 2:");                                         
    printf("\n\tTicket ID: SN001");
    printf("\n\tEvent Name: Siti Nurhaliza Concert");
    printf("\n\tEvent Date Available:");
    printf("\n\t\t[1] 28/09/2024 (Saturday) - 8pm");
    printf("\n\t\t[2] 26/10/2024 (Saturday) - 8pm");
    printf("\n\tSeat Section:");
    printf("\n\t\t[1] CAT 1 (VIP Pass) - RM 500.00");
    printf("\n\t\t[2] CAT 2 - RM 350.00");
    printf("\n\t\t[3] CAT 3 - RM 200.00");
        
    printf("\n\n\tConcert 3:");                                        
    printf("\n\tTicket ID: NI001");
    printf("\n\tEvent Name: Noraniza Idris Concert");
    printf("\n\tEvent Date Available:");
    printf("\n\t\t[1] 17/05/2024 (Friday) - 8pm");
    printf("\n\t\t[2] 14/06/2024 (Friday) - 8pm");
    printf("\n\tSeat Section:");
    printf("\n\t\t[1] CAT 1 (VIP Pass) - RM 150.00");
    printf("\n\t\t[2] CAT 2 - RM 100.00");
    printf("\n\t\t[3] CAT 3 - RM 50.00\n\n");
    
	printf("\n");
	int i;
	int eventChoice;
	int dateChoice;
	char seatChoice;
	for( i = 0 ; i < size ; i++ )
	{
	
	printf("Customer ID: ");
	scanf("%s", &t[i].custID);
	printf("Customer Name: ");
	scanf("%s",&t[i].custName);
	printf("Customer Phone Number: ");
	scanf("%s",&t[i].custPhoneNum);
	printf("Customer Age: ");
	scanf("%d",&t[i].custAge);
	printf("Customer State/City ( Address ) : ");
	scanf("%s",&t[i].custAdd);

	printf("\nChoose your preferent Ticket by Entering Concert Code [ 1 - AA001 | 2 - SN001 | 3 - NI001]: ");
	scanf("%d",&eventChoice);
	
	if(eventChoice == 1){
	strcpy( t[i].ticketID , "Aina Abdul Concert" );
	printf("Choose date (1/2) : ");
	scanf("%d", &dateChoice);
		if(dateChoice == 1){
			strcpy(t[i].eventDate,"24/01/2024 (Wednesday) - 8pm");
		}
		else{
			strcpy(t[i].date, "28/02/2024 (Wednesday) - 8pm");
		}
	}
	else
	if(eventChoice == 2){
	strcpy( t[i].ticketID , "Siti Nurhaliza Concert" );
	printf("Choose date (1/2) : ");
	scanf("%d",dateChoice);
		if(t[i].dateChoice == 1){
			strcpy(t[i].eventDate, "28/01/2024 (Saturday) - 8pm");
		}
		else{
			strcpy(t[i].eventDate, "26/01/2024 (Saturday) - 8pm");
		}
	}
	else if(eventChoice == 3){
	strcpy( t[i].ticketID , "Noraniza Idris Concert" );
	printf("Choose date (1/2) : ");
	scanf("%d",dateChoice);
		if(t[i].dateChoice == 1){
			strcpy(t[i].eventDate , "17/01/2024 (Friday) - 8pm");
		}
		else{
			strcpy(t[i].eventDate, "14/02/2024 (Friday) - 8pm");
		}
	}
		
	printf("Choose seat (1/2/3) : ");
	scanf(" %c", &seatChoice );
	if( seatChoice == '1' )
            strcpy( t[i].seatSection,"CAT 1 (VIP Pass)");
    else 
	if( seatChoice == '2' )
        strcpy( t[i].seatSection,"CAT 2");
    else 
	if( seatChoice == '3' )
        strcpy( t[i].seatSection,"CAT 3");
	
	int x;
	for ( x = 0; x < size ; x++ )
	{
		t[x].ticketPrice = calcPrice( t , x );
	}
	
	printf("\n");
  }
    
    printf("\n");
    calcTotalSales( t , size );	
    printf("\n");
    
    char concertName[3][50]={"Aina Abdul Concert","Siti Nurhaliza Concert", "Noraniza Idris"  };
    
    
    int eventNum;  
    printf("\n");
    printf("Total Attendees for Each Concert:\n");
    for ( eventNum = 1; eventNum <= 3; eventNum++) {
        int totalAttendees = calcTotalAttendees( t , size, eventNum);
        printf("Total Attendess for %s: %d\n", concertName[eventNum-1], totalAttendees);
    }
    
    printf("\n");
    calcHighest( t , i , size );
    
    printf("\n");
    calcLowest( t , i , size );	
    printf("\n");
    
	char updateChoice;
	printf("\nEnter [Y] to update phone numbers and [N] to skip: ");
	scanf(" %c", &updateChoice );
	
	while( updateChoice == 'Y' )
	{	
		updateData(t , i ,size);	
		printf("\nEnter [Y] to update phone numbers and [N] to stop: ");
		scanf(" %c", &updateChoice );
	}
	printf("\n");
	
	printf("\n");
	char removeChoice;
	printf("Enter [Y] to remove customer orders and [N] to skip: ");
	scanf(" %c", &removeChoice );
	while( removeChoice == 'Y' )
	{
	 	removeData(t , i ,size);
		size= size -1;
		
		printf("Enter [Y] to remove customer orders and [N] to stop: ");
		scanf(" %c", &removeChoice );
	}
	printf("\n");
	
  int j;
  for (j = 0; j < size; j++) {
  		
  		printf("\n==Customer Data %d==\n", j + 1);
  		printf("Event: %s\n",t[j].ticketID);
        printf("Date: %s\n",t[j].eventDate);
        printf("Seat: %s\n",t[j].seat);
        printf("Price: %.2f\n",t[j].ticketPrice);
        
        printf("\nCustomer ID: %s\n", t[j].custID);
        printf("Name: %s\n", t[j].custName);
        printf("Age: %d\n", t[j].custAge);
        printf("Address: %s\n", t[j].custAdd);
        printf("Phone Number: %s\n", t[j].custPhoneNum);
        printf("\n");
    }
	
  	return 0;
}
