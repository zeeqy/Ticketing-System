#include <stdio.h>
struct CustData{
	char name[50];
	char phonenum[50];
	int age;
	int event;
	int dateChoosen;
	char date[100];
	char seat;
	double price;
	
};

int main(){
	struct CustData cd[2];
	
	printf("--Ticket List--\n");
	printf("\n");
	printf("Concert 1:\n");
	printf("Ticket ID: JB001\n");
	printf("Event Name: Justin Bieber\n");
	printf("Event Date Available:\n");
	printf("1. 24/01/2024 (Wednesday) - 8pm\n");
	printf("2. 28/02/2024 (Wednesday) - 8pm\n");
	
	printf("Seat Section:\n");
	printf("A. section A - RM 300.00\n");
	printf("B. section B - RM 250.00\n");
	printf("C. section C - RM 150.00\n");
	
	printf("\n");
	printf("Concert 2:\n");
	printf("Ticket ID: SM001\n");
	printf("Event Name: Siti Nurhaliza\n");
	printf("Event Date Available:\n");
	printf("1. 28/01/2024 (Saturday) - 8pm\n");
	printf("2. 26/02/2024 (Saturday) - 8p\n");
	
	printf("Seat Section:\n");
	printf("A. section A - RM 500.00\n");
	printf("B. section B - RM 300.00\n");
	printf("C. section C - RM 150.00\n");
	
	printf("\n");
	printf("Concert 3:\n");
	printf("Ticket ID: TS001\n");
	printf("Event Name: Taylor Swift Concert\n");
	printf("Event Date Available:\n");
	printf("1. 17/01/2024 (Friday) - 8pm\n");
	printf("2. 14/02/2024 (Friday) - 8pm\n");
	
	printf("Seat Section:\n");
	printf("A. section A - RM 1000.00\n");
	printf("B. section B - RM 750.00\n");
	printf("C. section C - RM 5000.00\n");
	
	printf("\n");
	int i;
	for(i=0;i<2;i++){
		
	printf("Enter name:");
	scanf("%s",&cd[i].name);
	printf("Enter phone num:");
	scanf("%s",&cd[i].phonenum);
	printf("Enter age:");
	scanf("%d",&cd[i].age);

	printf("Choose event(1/2/3):");
	scanf("%d",&cd[i].event);
	
	if(cd[i].event == 1){
	printf("Choose date(1/2):");
	scanf("%d",&cd[i].dateChoosen);
		if(cd[i].dateChoosen == 1){
			strcpy(cd[i].date,"24/01/2024 (Wednesday) - 8pm");
		}
		else{
			strcpy(cd[i].date, "28/01/2024 (Wednesday) - 8pm");
		}
		
	printf("Choose seat(A/B/C): ");
	scanf(" %c", &cd[i].seat);
		if(cd[i].seat == 'A'){
			cd[i].price= 300.00;
		}
		else if(cd[i].seat == 'B'){
			cd[i].price= 250.00;
		}
		else if(cd[i].seat == 'C'){
			cd[i].price= 150.00;
		}
	}
	
	else if(cd[i].event == 2){
	printf("Choose date:(1/2)");
	scanf("%d",&cd[i].dateChoosen);
		if(cd[i].dateChoosen == 1){
			strcpy(cd[i].date, "28/01/2024 (Saturday) - 8pm");
		}
		else{
			strcpy(cd[i].date, "26/01/2024 (Saturday) - 8pm");
		}
		
	printf("Choose seat(A/B/C): ");
	scanf(" %c", &cd[i].seat);
		if(cd[i].seat == 'A'){
			cd[i].price= 500.00;
		}
		else if(cd[i].seat == 'B'){
			cd[i].price= 300.00;
		}
		else if(cd[i].seat == 'C'){
			cd[i].price= 150.00;
		}
	}
	else if(cd[i].event == 3){
	printf("Choose date(1/2):");
	scanf("%d",&cd[i].dateChoosen);
		if(cd[i].dateChoosen == 1){
			strcpy(cd[i].date , "17/01/2024 (Friday) - 8pm");
		}
		else{
			strcpy(cd[i].date, "14/01/2024 (Friday) - 8pm");
		}
		
	printf("Choose seat(A/B/C): ");
	scanf(" %c", &cd[i].seat);
		if(cd[i].seat == 'A'){
			cd[i].price= 1000.00;
		}
		else if(cd[i].seat == 'B'){
			cd[i].price= 750.00;
		}
		else if(cd[i].seat == 'C'){
			cd[i].price= 5000.00;
		}	
	}
	printf("\n");
  }
  
  int j;
  for (j = 0; j < 2; j++) {
        printf("--Customer Data %d--\n", j + 1);
        printf("Name: %s\n", cd[j].name);
        printf("Age: %d\n", cd[j].age);
        printf("Phone Number: %s\n", cd[j].phonenum);
        printf("Event: %d\n",cd[j].event);
        printf("Date: %s\n",cd[j].date);
        printf("Seat: %c\n",cd[j].seat);
        printf("Price: %.2f\n",cd[j].price);
        printf("\n");
    }
    
  return 0;
}
