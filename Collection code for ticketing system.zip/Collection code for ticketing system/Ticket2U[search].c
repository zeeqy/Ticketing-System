#include <stdio.h>
#include <string.h>

// Defining the Ticket struct
struct Ticket {
	
	char custID[100];
    char custName[50];
    char custPhoneNum[15];
    int custAge;
    char custAdd[100];
    int event;
    char ticketID[5];
    char eventName;
    int dateChoosen;
	char date[100];
    char eventDate;
    char seatSection;
    float ticketPrice;
    
};

// Function prototypes
float calcPrice( struct Ticket[] , int  );
void calcTotalSales( struct Ticket[] , int  );
void countSection( struct Ticket[] , int );
void calcHighest( struct Ticket[] , int , int );
void calcLowest( struct Ticket[] , int , int );
double calcTotalSale(struct Ticket[], int , int );
int calcTotalAttendees(struct Ticket[], int , int );
void searchData(struct Ticket[], int, int );

float calcPrice( struct Ticket t[] , int i )
{
	float total = 0;
	
        if( t[i].event == 1 ) 
        {
            if( t[i].seatSection == '1')
                total = 250.00;
            else
			if( t[i].seatSection == '2')
                total = 150.00;
            else 
			if( t[i].seatSection == '3')
                total = 300.00;
        }
        else
		if( t[i].event == 2 ) 
        {
            if( t[i].seatSection == '1')
                total = 300.00;
            else 
			if( t[i].seatSection == '2')
                total = 150.00;
            else 
			if( t[i].seatSection == '3')
                total = 500.00;
        }
        else 
		if( t[i].event == 3 ) 
        {
            if( t[i].seatSection == '1')
                total = 150.00;
            else 
			if( t[i].seatSection == '2')
                total = 100.00;
            else 
			if( t[i].seatSection == '3')
                total = 50.00;
        }
        
	return total;
}

//Count the total attendees for each section
void countSection( struct Ticket t[] , int size )
{
	int i;
	int catOne = 0;
	int catTwo = 0;
	int standingZone = 0;
	
	for (i = 0; i < size; i++) 
	{
		if( t[i].seatSection == '1' )
                catOne = catOne + 1;
        else 
		if( t[i].seatSection == '2' )
                catTwo = catTwo + 1;
        else 
		if( t[i].seatSection == '3' )
                standingZone = standingZone + 1;
    }
    
    printf("\nTotal customer that chose Cat One : %d", catOne);
    printf("\nTotal customer that chose Cat Two : %d", catTwo);
    printf("\nTotal customer that chose Standing Zone : %d", standingZone);
	
}

//Calculate the sum of all earnings from each event based on their name
void calcTotalSales( struct Ticket t[] , int size )
{
	int i;
	float sumAA = 0.00;
	float sumSN = 0.00;
	float sumNI = 0.00;
	
	for ( i = 0; i < size ; i++ )
	{
	if( t[i].event == 1 ) 
            sumAA = sumAA + calcPrice( t , i );
    else 
	if( t[i].event == 2 ) 
        sumSN = sumSN + calcPrice( t , i  );
    else 
	if( t[i].event == 1 ) 
        sumNI = sumNI + calcPrice( t , i  );
	}
    
    printf("\nTotal Earnings for Each Concert: ");
    printf("\nAina Abdul's Concert : RM%f", sumAA);
    printf("\nSiti Nurhaliza's Concert : RM%f", sumSN);
    printf("\nNoraniza Idris's Concert : RM%f", sumNI);
}

//Determine the maximum sales and attendees gained by comparing each event thoroughly
void calcHighest( struct Ticket t[] , int i , int size )
{
	int countAA = 0;
	int countSN = 0;
	int countNI = 0;
	int highestAtt = 0;
	float highestSales = 0.00; 
	float sumAA = 0.00;
	float sumSN = 0.00;
	float sumNI = 0.00;	
	char SalesName[50];
	char AttName[50];
	
	for ( i = 0; i < size; i++ ) 
	{
		if( t[i].event == 1 ) 
            {
				sumAA = sumAA + calcPrice( t , i );
				countAA = countAA + 1;
			}
        else 
		if( t[i].event == 2 ) 
            {
				sumSN = sumSN + calcPrice( t , i );
				countSN = countSN + 1;
			}
        else 
		if( t[i].event == 3 ) 
            {
				sumNI = sumNI + calcPrice( t , i );
				countNI = countNI + 1;
			}
    }
    
    if ( sumAA > highestSales )
        {
		  highestSales = sumAA;
		  strcpy( SalesName , "Aina Abdul's Concert");
    	}
    if ( sumSN > highestSales )
        {
		  highestSales = sumSN;
		  strcpy( SalesName,"Siti Nurhaliza's' Concert");
    	}
    if ( sumNI > highestSales )
        {
		  highestSales = sumNI;
		  strcpy( SalesName , "Noraniza Idris's' Concert");
    	}
         
    if ( countAA > highestAtt )
        {
         highestAtt = countAA;
         strcpy( AttName , "Aina Abdul's Concert" );
    	}
    if ( countSN > highestAtt )
        {
		  highestAtt = countSN;
		  strcpy( AttName , "Siti Nurhaliza's Concert" );
    	}
    if ( countNI > highestAtt )
        {
		  highestAtt = countNI;
		  ( AttName , "Noraniza Idris's Concert" );
    	}
    
	printf("\nName of highest attended event : %s", AttName );     
    printf("\nTotal attendees for the highest event : %d", highestAtt);
    
    printf("\nName of highest sales gained from an event : %s", SalesName);     
    printf("\nTotal attendees for the highest event : %f", highestSales);
    
}

//Determine the lowest sales and attendees gained by comparing each event thoroughly
void calcLowest( struct Ticket t[] , int i , int size )
{
	int countAA = 0;
	int countSN = 0;
	int countNI = 0;
	int lowestAtt = 999;
	float lowestSales = 999999.00; 
	float sumAA = 0.00;
	float sumSN = 0.00;
	float sumNI = 0.00;
	char SalesName[50];
	char AttName[50];
	
	for (i = 0; i < size; i++ ) 
	{
		if( t[i].event == 1 ) 
            {
				sumAA = sumAA + calcPrice( t , i );
				countAA = countAA + 1;
			}
        else 
		if( t[i].event == 2 ) 
            {
				sumSN = sumSN + calcPrice( t , i );
				countSN = countSN + 1;
			}
        else 
		if( t[i].event == 3 ) 
			{
				sumNI = sumNI + calcPrice( t , i );
				countNI = countNI + 1;
			}
    }
    
    if ( sumAA < lowestSales )
        {
		  lowestSales = sumAA;
		  strcpy( SalesName , "Aina Abdul's Concert");
    	}
    if ( sumSN < lowestSales )
        {
		  lowestSales = sumSN;
		  strcpy( SalesName , "Siti Nurhaliza's Concert");
    	}
    if ( sumNI < lowestSales )
        {
		  lowestSales = sumNI;
		  strcpy( SalesName , "Noraniza Idris's Concert");
    	}
         
    if ( countAA < lowestAtt )
        {
         lowestAtt = countAA;
         strcpy( AttName , "Aina Abdul's Concert" );
    	}
    if ( countSN < lowestAtt )
        {
		  lowestAtt = countSN;
		  strcpy( AttName , "Siti Nurhaliza's Concert" );
    	}
    if ( countNI < lowestAtt )
        {
		  lowestAtt = countNI;
		  strcpy( AttName , "Noraniza Idris's Concert");
    	}
    
	printf("\nName of lowest attended event : %s", AttName);     
    printf("\nTotal attendees for the lowest event : %d", lowestAtt);
    
    printf("\nName of lowest sales gained from an event : %s", SalesName);     
    printf("\nTotal sales for the lowest event : %f", lowestSales);
    
}

int calcTotalAttendees(struct Ticket t[] , int numOfCustomers, int eventNum){
	int totalAttendees=0;
	int i;
	for( i=0; i<numOfCustomers; i++){
		if( t[i].event == eventNum){
			totalAttendees = totalAttendees + 1;
		}
	}
	
	return totalAttendees;
}

void updateData(struct Ticket t[], int i, int size){
	printf("\n");
    char enterID[100];
    char enterName[100];
    printf("Enter customer's ID to update phone Numbers:\n");
    scanf("%s", enterID);
    printf("Enter customer's Name to update phone Numbers:\n");
    scanf("%s", enterName);

    int found = 0;
    for (i = 0; i < size; i++) {
        if (strcmp(t[i].custID, enterID) == 0 && strcmp(t[i].custName, enterName) == 0) {
            char newPhone[50];
            printf("Enter new phone number to update: ");
            scanf("%s", newPhone);
            strcpy(t[i].custPhoneNum, newPhone);
            found = 1;
            break;
        }
    }

    if (found) {
        printf("Phone number updated successfully.\n");
    } else {
        printf("Customer not found.\n");
    }
	
}

void removeData(struct Ticket t[], int i, int size){
    char findID[100];
    printf("Enter ID to remove your orders: ");
    scanf("%s", findID);
    
    int found = 0;
    for(i = 0; i < size; i++){
        if(strcmp(t[i].custID, findID) == 0){
            found = 1;
            int s;
            for(s = i; s < size-1; s++){
            	printf("its in!");
                strcpy(t[s].custID, t[s+1].custID);
                strcpy(t[s].custName, t[s+1].custName);
                t[s].custAge = t[s+1].custAge;
                strcpy(t[s].custAdd, t[s+1].custAdd);
                strcpy(t[s].custPhoneNum, t[s+1].custPhoneNum);
                t[s].eventName = t[s+1].eventName;
                strcpy(t[s].date, t[s+1].date);
                t[s].seatSection = t[s+1].seatSection;
                t[s].ticketPrice = t[s+1].ticketPrice;
            }
        }
    }
    
    if(!found){
		 printf("ID are not in the data. Please enter a valid ID. \n");
	}
}


int main(){
	int size = 2;
	struct Ticket t[ size ];
	
	printf("-----------------------");
	printf("      Ticket List     \n");
	printf("-----------------------");
	printf("\n");
	printf("Concert 1:\n");
	printf("Ticket ID: AA001\n");
	printf("Event Name: Aina Abdul's Concert'\n");
	printf("Event Date Available:\n");
	printf("   [1]24/01/2024 (Wednesday) - 8pm\n");
	printf("   [2]28/02/2024 (Wednesday) - 8pm\n");
	
	printf("Seat Section:\n");
	printf("   [1]Cat 1 (VIP pass)- RM 300.00\n");
	printf("   [2]Cat 2 - RM 250.00\n");
	printf("   [3]Cat 3 - RM 100.00\n");
	
	printf("\n");
	printf("Concert 2:\n");
	printf("Ticket ID: SN001\n");
	printf("Event Name: Siti Nurhaliza Concert \n");
	printf("Event Date Available:\n");
	printf("   [1]28/01/2024 (Saturday) - 8pm\n");
	printf("   [2]26/02/2024 (Saturday) - 8pm\n");
	
	printf("Seat Section:\n");
	printf("   [1]Cat 1 (VIP pass)- RM 300.00\n");
	printf("   [2]Cat 2 - RM 250.00\n");
	printf("   [3]Cat 3 - RM 100.00\n");
	
	printf("\n");
	printf("Concert 3:\n");
	printf("Ticket ID: NN001\n");
	printf("Event Name: Noraniza Idris Concert\n");
	printf("Event Date Available:\n");
	printf("   [1]17/01/2024 (Friday) - 8pm\n");
	printf("   [2]14/02/2024 (Friday) - 8pm\n");
	
	printf("Seat Section:\n");
	printf("   [1]Cat 1 (VIP pass)- RM 150.00\n");
	printf("   [2]Cat 2 - RM 100.00\n");
	printf("   [3]Cat 3 - RM 50.00\n");
	
	printf("\n");
	int i;
	for( i = 0 ; i < size ; i++ )
	{
	
	printf("Customer %d\n",i+1);
	printf("Enter Customer ID: ");
	scanf("%s", &t[i].custID);
	printf("Customer Name : ");
	scanf("%s",&t[i].custName);
	printf("Customer Number : ");
	scanf("%s",&t[i].custPhoneNum);
	printf("Customer Age : ");
	scanf("%d",&t[i].custAge);
	printf("Customer Address : ");
	scanf("%s",&t[i].custAdd);
	
	printf("Ticket Order %d\n",i+1);
	printf("Choose your preferent Ticket by Entering Concert Code [AA|SN|NI]: ");
	scanf("%d",&t[i].event);
	
	if(t[i].event == 1){
	printf("Enter Event Date you Prefer [1|2] :" );
	scanf("%d",&t[i].dateChoosen);
		if(t[i].dateChoosen == 1){
			strcpy(t[i].date,"24/01/2024 (Wednesday) - 8pm");
		}
		else{
			strcpy(t[i].date, "28/02/2024 (Wednesday) - 8pm");
		}
	}
	else
	if(t[i].event == 2){
	printf("Choose date(1/2) : ");
	scanf("%d",&t[i].dateChoosen);
		if(t[i].dateChoosen == 1){
			strcpy(t[i].date, "28/01/2024 (Saturday) - 8pm");
		}
		else{
			strcpy(t[i].date, "26/01/2024 (Saturday) - 8pm");
		}
	}
	else if(t[i].event == 3 ){
	printf("Choose date(1/2) : ");
	scanf("%d",&t[i].dateChoosen);
		if(t[i].dateChoosen == 1){
			strcpy(t[i].date , "17/01/2024 (Friday) - 8pm");
		}
		else{
			strcpy(t[i].date, "14/02/2024 (Friday) - 8pm");
		}
	}
		
	printf("Enter Seat Section you Prefer [1|2|3]");
	scanf(" %c", &t[i].seatSection );
	
	int x;
	for ( x = 0; x < size ; x++ )
	{
		t[i].ticketPrice = calcPrice( t , x );
	}
	
	printf("\n");
  }
    
    printf("\n");
    calcTotalSales( t , size );	
    printf("\n");
    
    char concertName[3][50]={"Aina Abdul Concert","Siti Nurhaliza Concert", "Noraniza Idris"  };
    
    int eventNum;  
    printf("\n");
    printf("Total Attendees for Each Concert:\n");
    for ( eventNum = 1; eventNum <= 3; eventNum++) {
        int totalAttendees = calcTotalAttendees( t , size, eventNum);
        printf("Total Attendess for %s: %d\n", concertName[eventNum-1], totalAttendees);
    }
    
    printf("\n");
    calcHighest( t , i , size );
    
    printf("\n");
    calcLowest( t , i , size );	
    printf("\n");
    
	
	printf("\n");
	char updateChoice;
	printf("Enter [Y] to update phone numbers and [N] to skip: ");
	scanf(" %c", &updateChoice );
		if(updateChoice == 'Y'){
		 updateData(t , i ,size);
		}
	printf("\n");
	
	printf("\n");
	char removeChoice;
	printf("Enter [Y] to remove customer orders and [N] to skip: ");
	scanf(" %c", &removeChoice );
		if(removeChoice == 'Y'){
		 removeData(t , i ,size);
		 size= size -1;
		}
	printf("\n");
	
  int j;
  for (j = 0; j < size; j++) {
        printf("--Customer Data %d--\n", j + 1);
        printf("Customer ID: %s\n", t[j].custID);
        printf("Name: %s\n", t[j].custName);
        printf("Age: %d\n", t[j].custAge);
        printf("Address: %s\n", t[j].custAdd);
        printf("Phone Number: %s\n", t[j].custPhoneNum);
        printf("Event: %d\n",t[j].eventName);
        printf("Date: %s\n",t[j].date);
        printf("Seat: %c\n",t[j].seatSection);
        printf("Price: %.2f\n",t[j].ticketPrice);
        printf("\n");
    }
	
  	return 0;
}
