#include <stdio.h>
struct CustData{
	char name[50];
	char phonenum[50];
	int age;
	int event;
	char eventName[100];
	int dateChoosen;
	char date[100];
	char seat;
	double price;
	
};

double calcTotalSale(struct CustData cd[], int numOfCustomers, int eventNum);
int calcTotalAttandees(struct CustData cd[],int numOfCustomers, int eventNum);

int main(){
	struct CustData cd[2];
	
	printf("--Ticket List--\n");
	printf("\n");
	printf("Event 1:\n");
	printf("Ticket ID: JB001\n");
	printf("Event Name: Justin Bieber Concert\n");
	printf("Event Date Available:\n");
	printf("1. 24/01/2024 (Wednesday) - 8pm\n");
	printf("2. 28/02/2024 (Wednesday) - 8pm\n");
	
	printf("Seat Section:\n");
	printf("A. section A - RM 300.00\n");
	printf("B. section B - RM 250.00\n");
	printf("C. section C - RM 150.00\n");
	
	printf("\n");
	printf("Event 2:\n");
	printf("Ticket ID: SM001\n");
	printf("Event Name: Siti Nurhaliza Concert\n");
	printf("Event Date Available:\n");
	printf("1. 28/01/2024 (Saturday) - 8pm\n");
	printf("2. 26/02/2024 (Saturday) - 8p\n");
	
	printf("Seat Section:\n");
	printf("A. section A - RM 500.00\n");
	printf("B. section B - RM 300.00\n");
	printf("C. section C - RM 150.00\n");
	
	printf("\n");
	printf("Event 3:\n");
	printf("Ticket ID: TS001\n");
	printf("Event Name: Taylor Swift Concert\n");
	printf("Event Date Available:\n");
	printf("1. 17/01/2024 (Friday) - 8pm\n");
	printf("2. 14/02/2024 (Friday) - 8pm\n");
	
	printf("Seat Section:\n");
	printf("A. section A - RM 1000.00\n");
	printf("B. section B - RM 750.00\n");
	printf("C. section C - RM 5000.00\n");
	
	printf("\n");
	int i;
	for(i=0;i<2;i++){
		
	printf("Enter name:");
	scanf("%s",&cd[i].name);
	printf("Enter phone num:");
	scanf("%s",&cd[i].phonenum);
	printf("Enter age:");
	scanf("%d",&cd[i].age);

	printf("Choose event(1/2/3):");
	scanf("%d",&cd[i].event);
	
	if(cd[i].event == 1){
		
	strcpy(cd[i].eventName,"Justin Bieber Concert");			
	printf("Choose date(1/2):");
	scanf("%d",&cd[i].dateChoosen);
		if(cd[i].dateChoosen == 1){
			strcpy(cd[i].date,"24/01/2024 (Wednesday) - 8pm");
		}
		else{
			strcpy(cd[i].date, "28/01/2024 (Wednesday) - 8pm");
		}
		
	printf("Choose seat(A/B/C): ");
	scanf(" %c", &cd[i].seat);
		if(cd[i].seat == 'A'){
			cd[i].price= 300.00;
		}
		else if(cd[i].seat == 'B'){
			cd[i].price= 250.00;
		}
		else if(cd[i].seat == 'C'){
			cd[i].price= 150.00;
		}
	}
	
	else if(cd[i].event == 2){
	
	strcpy(cd[i].eventName,"Siti Nurhaliza Concert");
	printf("Choose date:(1/2)");
	scanf("%d",&cd[i].dateChoosen);
		if(cd[i].dateChoosen == 1){
			strcpy(cd[i].date, "28/01/2024 (Saturday) - 8pm");
		}
		else{
			strcpy(cd[i].date, "26/01/2024 (Saturday) - 8pm");
		}
		
	printf("Choose seat(A/B/C): ");
	scanf(" %c", &cd[i].seat);
		if(cd[i].seat == 'A'){
			cd[i].price= 500.00;
		}
		else if(cd[i].seat == 'B'){
			cd[i].price= 300.00;
		}
		else if(cd[i].seat == 'C'){
			cd[i].price= 150.00;
		}
	}
	else if(cd[i].event == 3){
		
	strcpy(cd[i].eventName,"Taylor Swift Concert");
	printf("Choose date(1/2):");
	scanf("%d",&cd[i].dateChoosen);
		if(cd[i].dateChoosen == 1){
			strcpy(cd[i].date , "17/01/2024 (Friday) - 8pm");
		}
		else{
			strcpy(cd[i].date, "14/01/2024 (Friday) - 8pm");
		}
		
	printf("Choose seat(A/B/C): ");
	scanf(" %c", &cd[i].seat);
		if(cd[i].seat == 'A'){
			cd[i].price= 1000.00;
		}
		else if(cd[i].seat == 'B'){
			cd[i].price= 750.00;
		}
		else if(cd[i].seat == 'C'){
			cd[i].price= 5000.00;
		}	
	}
	printf("\n");
  }
  
  int j;
  for (j = 0; j < 2; j++) {
        printf("--Customer Data %d--\n", j + 1);
        printf("Name: %s\n", cd[j].name);
        printf("Age: %d\n", cd[j].age);
        printf("Phone Number: %s\n", cd[j].phonenum);
        printf("Event: %s\n",cd[j].eventName);
        printf("Date: %s\n",cd[j].date);
        printf("Seat: %c\n",cd[j].seat);
        printf("Price: %.2f\n",cd[j].price);
        printf("\n");
    }
   
   char concertName[3][50]={
		"Justin Bieber Concert","Siti Nurhaliza Concert", "Taylor Swift"
   };
   
  int eventNum;   
  for (eventNum = 1; eventNum <= 3; eventNum++) {
        double totalSale = calcTotalSale(cd, 2, eventNum);
        printf("Total Sale for %s: RM %.2f\n", concertName[eventNum-1], totalSale);
    }
    
    printf("\n");
    
   for (eventNum = 1; eventNum <= 3; eventNum++) {
        int totalAttandees = calcTotalAttandees(cd, 2, eventNum);
        printf("Total Attandess for %s: %d\n", concertName[eventNum-1], totalAttandees);
    }
    
  return 0;
}

double calcTotalSale(struct CustData cd[], int numOfCustomers, int eventNum) {
    double totalSale = 0;
    int i;
    for (i = 0; i < numOfCustomers; i++) {
        if (cd[i].event == eventNum) {
            totalSale += cd[i].price;
        }
    }
    
    return totalSale;
}

int calcTotalAttandees(struct CustData cd[],int numOfCustomers, int eventNum){
	int totalAttandees=0;
	int i;
	for(i=0; i<numOfCustomers; i++){
		if(cd[i].event == eventNum){
			totalAttandees= totalAttandees + 1;
		}
	}
	
	return totalAttandees;
}
